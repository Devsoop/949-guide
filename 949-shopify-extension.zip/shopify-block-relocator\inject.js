// ============================================================
// 949 Order Page Tweaks v4
//  - Moves the app block (bundle editor) to the top of the order page
//  - Hides the order "Edit" button (header + overflow menus, Shadow DOM)
//  - Hides the line-items list inside the fulfillment card
//  - Moves the "Deleted items" card to the bottom of the page
//    (or hides it entirely — popup checkbox)
//
// All selectors are HARDCODED below. If Shopify changes its class
// names, update these constants — the team never touches selectors.
// ============================================================

// --- Selectors (update here if Shopify changes class names) ---

// App block wrapper. Class looks like _OrderDetailsAppBlockExtensionsWrapper_6wznd_116;
// the trailing hash changes between Shopify deploys, so match the stable part.
const MOVE_BLOCK_SELECTOR = '[class*="OrderDetailsAppBlockExtensionsWrapper"]';

// Line-items list in the fulfillment card (_LineItemGroup_z9606_1 etc.)
const LINE_ITEMS_SELECTOR = '[class*="LineItemGroup"]';

// Order "Edit" button, OLD admin markup: an <s-internal-button href=".../orders/<id>/edit">
// inside Shadow DOM, repeated in overflow menus. Pure CSS can target these by href.
const EDIT_BTN_SELECTOR =
  's-internal-button[href*="/orders/"][href$="/edit"], a[href*="/orders/"][href$="/edit"]';

// Spring '26 admin REMOVED the href from the Edit button (now <s-internal-button id="Edit">
// slotted into <s-internal-page>, plus href-less copies in menus), so CSS attribute
// selectors can't catch it anymore. These candidates are matched by EXACT text "Edit"
// in JS instead (hideEditButtonsByText). Exact-match keeps the app block's "View/Edit"
// and icon-only pencil buttons (no text) safe.
const EDIT_BTN_TEXT_CANDIDATES = 's-internal-button, button[role="menuitem"]';
const EDIT_HIDE_ATTR = 'data-block-relocator-edit-hidden';

// The "Deleted items" card has no stable class we can rely on, so it's found by its
// HEADING TEXT (whole trimmed text of a heading element). Shopify has labeled this
// section "Deleted items", "Removed items", and currently "Removed (N)" with the
// line count — match any of them.
const DELETED_HEADING_RE = /^(deleted|removed)(\s+items?)?(\s*\(\d+\))?$/i;

// --- Settings (all default ON; the block move ALWAYS runs) ---

const DEFAULTS = { hideEditBtn: true, hideLineItems: true, hideDeletedItems: true };
let settings = { ...DEFAULTS };
let debounceTimer = null;

chrome.storage.sync.get(DEFAULTS, (data) => {
  settings = data;
  startWatching();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'applySettings') {
    settings = { ...DEFAULTS, ...request.settings };
    if (!settings.hideEditBtn && !settings.hideLineItems) {
      removeHides();
    }
    runAutoActions();
    sendResponse({ ok: true });
  }
  return true; // keep channel open for async sendResponse
});

// ------------------------------------------------------------
// Move: uses insertBefore which MOVES the live node (no clone),
// so Shadow DOM, listeners, and app iframe state survive.
// ------------------------------------------------------------
function findMainContainer() {
  const candidates = [
    '[class*="OrderDetailsMainColumn"]',
    '[class*="OrderDetailsLayout"]',
    'main',
    '[role="main"]'
  ];
  for (const sel of candidates) {
    const el = document.querySelector(sel);
    if (el) return el;
  }
  return document.body;
}

function moveToTop(element) {
  if (!element) return false;

  const container = findMainContainer();
  if (!container) return false;

  // Climb to the direct child of the container so we move the
  // whole block, not just an inner fragment.
  let moveTarget = element;
  let parent = moveTarget.parentElement;
  while (parent && parent !== container && parent.parentElement !== container) {
    moveTarget = parent;
    parent = parent.parentElement;
  }
  if (parent !== container && moveTarget.parentElement !== container) {
    moveTarget = element;
  }

  if (container.firstElementChild === moveTarget) {
    return true; // already at top
  }

  moveTarget.setAttribute('data-relocated-ext', 'true');
  container.insertBefore(moveTarget, container.firstElementChild);
  return true;
}

function attemptAutoMove() {
  let el;
  try {
    el = document.querySelector(MOVE_BLOCK_SELECTOR);
  } catch (e) {
    return;
  }
  if (el && !el.hasAttribute('data-relocated-ext') && el.closest('[data-relocated-ext]') === null) {
    moveToTop(el);
  }
}

// ------------------------------------------------------------
// "Deleted items" card: HIDDEN (popup checkbox, on by default).
// Found by heading text, since it has no stable class.
// Unchecking the box restores it immediately (marker attribute).
// ------------------------------------------------------------
const DELETED_ATTR = 'data-deleted-items-ext';

// Headings on the order page are <s-internal-heading> in the current admin; keep the
// generic fallbacks for older markup.
const DELETED_HEADING_SELECTOR = 'h1, h2, h3, h4, h5, h6, s-internal-heading, [class*="Heading"]';

function findDeletedItemsCard() {
  const container = findMainContainer();
  const headings = container.querySelectorAll(DELETED_HEADING_SELECTOR);
  for (const h of headings) {
    if (!DELETED_HEADING_RE.test((h.textContent || '').trim())) continue;
    // The card is the heading's Polaris-Box ancestor (one Box per card in the main
    // column's BlockStack). Fallback: climb to the container's direct child. If neither
    // resolves, skip rather than move something random.
    const box = h.closest('.Polaris-Box');
    if (box) return box;
    let card = h;
    while (card.parentElement && card.parentElement !== container) card = card.parentElement;
    if (card.parentElement === container) return card;
  }
  return null;
}

function attemptDeletedItems() {
  if (!settings.hideDeletedItems) {
    restoreDeletedItems();
    return;
  }
  const card = findDeletedItemsCard();
  if (!card) return;
  card.setAttribute(DELETED_ATTR, 'true');
  if (card.style.display !== 'none') card.style.display = 'none';
}

// Un-hide a previously hidden card (setting turned off mid-session).
function restoreDeletedItems() {
  document.querySelectorAll(`[${DELETED_ATTR}]`).forEach((el) => {
    if (el.style.display === 'none') el.style.display = '';
  });
}

// ------------------------------------------------------------
// Hiding engine.
//  1. Light-DOM elements (LineItemGroup) - a normal <style> tag
//     covers these, including elements that render later.
//  2. Shadow-DOM elements (the Edit button) - document CSS can't
//     reach inside shadow roots, so we inject the same <style>
//     into every OPEN shadow root and re-walk on navigation /
//     mutations / menu opens.
// ------------------------------------------------------------
const HIDE_STYLE_ATTR = 'data-block-relocator-hide';

function buildHideCss() {
  const parts = [];
  if (settings.hideEditBtn) {
    parts.push(`${EDIT_BTN_SELECTOR} { display: none !important; }`);
  }
  if (settings.hideLineItems) {
    parts.push(`${LINE_ITEMS_SELECTOR} { display: none !important; }`);
  }
  return parts.join('\n');
}

function ensureHideStyle(root, css) {
  const host = root === document ? document.head || document.documentElement : root;
  let style = host.querySelector(`style[${HIDE_STYLE_ATTR}]`);
  if (!css) {
    if (style) style.remove();
    return;
  }
  if (!style) {
    style = document.createElement('style');
    style.setAttribute(HIDE_STYLE_ATTR, 'true');
    host.appendChild(style);
  }
  if (style.textContent !== css) style.textContent = css;
}

// Visit every open shadow root in the document (recursively).
function forEachShadowRoot(cb, root = document) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let node = walker.currentNode;
  while (node) {
    if (node.shadowRoot) {
      cb(node.shadowRoot);
      forEachShadowRoot(cb, node.shadowRoot);
    }
    node = walker.nextNode();
  }
}

/**
 * Spring '26 Edit buttons carry no href, so they're hidden per-element by EXACT text
 * match instead of CSS. Runs against one root (document or a shadow root).
 */
function hideEditButtonsByText(root) {
  root.querySelectorAll(EDIT_BTN_TEXT_CANDIDATES).forEach((el) => {
    if ((el.textContent || '').trim() !== 'Edit') return;
    if (el.style.display !== 'none') {
      el.setAttribute(EDIT_HIDE_ATTR, 'true');
      el.style.display = 'none';
    }
  });
}

function restoreEditButtons(root) {
  root.querySelectorAll(`[${EDIT_HIDE_ATTR}]`).forEach((el) => {
    el.style.display = '';
    el.removeAttribute(EDIT_HIDE_ATTR);
  });
}

function applyHides() {
  const css = buildHideCss();
  const perRoot = settings.hideEditBtn ? hideEditButtonsByText : restoreEditButtons;
  ensureHideStyle(document, css);
  perRoot(document);
  forEachShadowRoot((shadowRoot) => {
    ensureHideStyle(shadowRoot, css);
    perRoot(shadowRoot);
  });
}

function removeHides() {
  ensureHideStyle(document, '');
  restoreEditButtons(document);
  forEachShadowRoot((shadowRoot) => {
    ensureHideStyle(shadowRoot, '');
    restoreEditButtons(shadowRoot);
  });
}

// ------------------------------------------------------------
// SPA navigation detection.
// Shopify admin uses client-side routing, so we patch
// pushState/replaceState + listen for popstate, and also run
// a lightweight MutationObserver as a fallback.
// ------------------------------------------------------------
function notifyLocationChange() {
  window.dispatchEvent(new Event('spa-locationchange'));
}

(function patchHistory() {
  const origPush = history.pushState;
  const origReplace = history.replaceState;
  history.pushState = function (...args) {
    origPush.apply(history, args);
    notifyLocationChange();
  };
  history.replaceState = function (...args) {
    origReplace.apply(history, args);
    notifyLocationChange();
  };
  window.addEventListener('popstate', notifyLocationChange);
})();

function runAutoActions() {
  attemptAutoMove();
  attemptDeletedItems();
  if (settings.hideEditBtn || settings.hideLineItems) applyHides();
}

function debounceAttempt() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(runAutoActions, 500);
}

let watching = false;
function startWatching() {
  if (watching) {
    runAutoActions();
    return;
  }
  watching = true;

  // Try immediately (in case the page is already rendered)
  runAutoActions();

  // Re-try on SPA route change (allow time for React to render)
  window.addEventListener('spa-locationchange', () => {
    setTimeout(runAutoActions, 700);
    setTimeout(runAutoActions, 1500); // second attempt for slow-loading blocks
  });

  // Fallback: watch DOM mutations in case content loads async
  // without a URL change. Debounced to avoid performance issues.
  const observer = new MutationObserver(() => {
    debounceAttempt();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Menus (More actions dropdown) create NEW shadow roots when they
  // open, and a document observer can't see inside them. A click
  // anywhere is the cheapest reliable signal that a menu may have
  // just rendered - re-apply hides shortly after.
  document.addEventListener('click', () => {
    if (!settings.hideEditBtn && !settings.hideLineItems) return;
    setTimeout(applyHides, 100);
    setTimeout(applyHides, 400);
  }, true);
}
