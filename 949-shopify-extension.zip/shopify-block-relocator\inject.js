// ============================================================
// 949 Order Page Tweaks v4.1
//  - Moves the app block (bundle editor) to the top of the order page
//  - Hides the order "Edit" button (header + overflow menus, Shadow DOM)
//  - Hides the line-items list inside the fulfillment card
//  - Hides the "Removed"/"Deleted items" card (popup checkbox)
//
// EVERYTHING is scoped to ORDER DETAIL PAGES ONLY. On any other admin page
// all hides are removed and any leftover relocated block is cleaned up.
//
// All selectors are HARDCODED below. If Shopify changes its class
// names, update these constants — the team never touches selectors.
// ============================================================

// --- Selectors (update here if Shopify changes class names) ---

// App block wrapper. Class looks like _OrderDetailsAppBlockExtensionsWrapper_6wznd_116;
// the trailing hash changes between Shopify deploys, so match the stable part.
const MOVE_BLOCK_SELECTOR = '[class*="OrderDetailsAppBlockExtensionsWrapper"]';

// Line-items list in the fulfillment card.
//  - Old markup: a single _LineItemGroup_z9606_1 wrapper.
//  - Current markup (Nov '26): each row is a _LineItemContainer_shcz3_xx inside a
//    _Grid_agsy0_7 wrapper (rows + _RowDivider children). Hide the grid wrapper
//    (via :has) so the dividers go too, with the per-row rule as a fallback.
const LINE_ITEMS_SELECTOR =
  '[class*="LineItemGroup"], div:has(> [class*="LineItemContainer"]), [class*="LineItemContainer"]';

// Order "Edit" button, OLD admin markup: an <s-internal-button href=".../orders/<id>/edit">
// inside Shadow DOM, repeated in overflow menus. Pure CSS can target these by href.
const EDIT_BTN_SELECTOR =
  's-internal-button[href*="/orders/"][href$="/edit"], a[href*="/orders/"][href$="/edit"]';

// Spring '26 admin REMOVED the href from the Edit button (now <s-internal-button id="Edit">
// slotted into <s-internal-page>, plus href-less copies in menus), so CSS attribute
// selectors can't catch it anymore. These candidates are matched by EXACT text "Edit"
// in JS instead (hideEditButtonsByText). Exact-match keeps the app block's "View/Edit"
// and icon-only pencil buttons (no text) safe.
const EDIT_BTN_TEXT_CANDIDATES = 's-internal-button, button[role="menuitem"]';
const EDIT_HIDE_ATTR = 'data-block-relocator-edit-hidden';

// The "Deleted items" card has no stable class we can rely on, so it's found by its
// HEADING TEXT (whole trimmed text of a heading element). Shopify has labeled this
// section "Deleted items", "Removed items", and currently "Removed (N)" with the
// line count — match any of them.
const DELETED_HEADING_RE = /^(deleted|removed)(\s+items?)?(\s*\(\d+\))?$/i;

// Marker attributes on nodes we touched.
const RELOCATED_ATTR = 'data-relocated-ext';        // the moved app block
const RELOCATED_ORDER_ATTR = 'data-relocated-order'; // which order it was moved on
const DELETED_ATTR = 'data-deleted-items-ext';       // hidden "Removed" card
const HIDE_STYLE_ATTR = 'data-block-relocator-hide'; // injected <style> tags

// --- Settings (all default ON; the block move ALWAYS runs) ---

const DEFAULTS = { hideEditBtn: true, hideLineItems: true, hideDeletedItems: true };
let settings = { ...DEFAULTS };

chrome.storage.sync.get(DEFAULTS, (data) => {
  settings = data;
  startWatching();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'applySettings') {
    settings = { ...DEFAULTS, ...request.settings };
    if (!settings.hideEditBtn && !settings.hideLineItems) {
      removeHides();
    }
    runAutoActions();
    sendResponse({ ok: true });
  }
  return true; // keep channel open for async sendResponse
});

// ------------------------------------------------------------
// Page detection. Only the order DETAIL page (/orders/<id>) counts;
// /orders (list), /orders/<id>/edit, /draft_orders/... do not.
// ------------------------------------------------------------
function currentOrderId() {
  const m = /\/orders\/(\d+)\/?$/.exec(location.pathname);
  return m ? m[1] : null;
}

function isOrderDetailPage() {
  return currentOrderId() !== null;
}

// ------------------------------------------------------------
// Move: uses insertBefore which MOVES the live node (no clone),
// so Shadow DOM, listeners, and app iframe state survive.
// ------------------------------------------------------------
function findMainContainer() {
  // Old admin layout (pre Spring '26): a dedicated main-column div.
  const oldColumn = document.querySelector('[class*="OrderDetailsMainColumn"]');
  if (oldColumn) return oldColumn;

  // New admin layout: <s-internal-page> builds the columns in Shadow DOM
  // via <slot>s. Its light-DOM children carry slot attributes:
  //   slot="aside"             -> right side column (Notes, Customer, ...)
  //   slot="secondary-actions" -> header buttons
  //   (no slot attribute)      -> THE MAIN CARDS COLUMN (default slot)
  // Insert into the default-slot child so the block stacks ABOVE the
  // fulfillment/payment cards. Inserting anywhere higher (the page/main
  // element) makes the block render as its own column beside the cards.
  const page = document.querySelector('[class*="OrderDetailsPrintScope"] s-internal-page')
    || document.querySelector('s-internal-page');
  if (page) {
    const mainSlot = [...page.children].find(
      c => !c.hasAttribute('slot') && c.tagName !== 'STYLE' && c.tagName !== 'SCRIPT'
    );
    if (mainSlot) return mainSlot;
  }

  // Interim layout: a grid section whose widest non-wrapper child is the
  // main cards column.
  const layout = document.querySelector('[class*="OrderDetailsLayout"]');
  if (layout) {
    const wrapper = document.querySelector(MOVE_BLOCK_SELECTOR);
    const children = [...layout.children].filter(
      c => c !== wrapper && !(wrapper && (c.contains(wrapper) || wrapper.contains(c)))
    );
    if (children.length >= 2) {
      let best = children[0];
      for (const c of children) {
        if (c.getBoundingClientRect().width > best.getBoundingClientRect().width + 1) best = c;
      }
      return best;
    }
  }

  // Nothing confident found - return null so the caller skips this
  // attempt and retries on the next tick instead of moving the block
  // somewhere wrong (NEVER <main> or <body>: those persist across SPA
  // navigation and the block would leak onto every other admin page).
  return null;
}

function moveToTop(element) {
  if (!element) return false;

  const container = findMainContainer();
  if (!container) return false;

  // Climb to the direct child of the container so we move the
  // whole block, not just an inner fragment. Staying inside the same
  // parent also keeps React's own unmount (parent.removeChild) working.
  let moveTarget = element;
  let parent = moveTarget.parentElement;
  while (parent && parent !== container && parent.parentElement !== container) {
    moveTarget = parent;
    parent = parent.parentElement;
  }
  if (parent !== container && moveTarget.parentElement !== container) {
    moveTarget = element;
  }

  moveTarget.setAttribute(RELOCATED_ATTR, 'true');
  moveTarget.setAttribute(RELOCATED_ORDER_ATTR, currentOrderId() || '');
  moveTarget.style.display = '';

  if (container.firstElementChild !== moveTarget) {
    container.insertBefore(moveTarget, container.firstElementChild);
  }
  return true;
}

function attemptAutoMove() {
  let candidates;
  try {
    candidates = [...document.querySelectorAll(MOVE_BLOCK_SELECTOR)];
  } catch (e) {
    return;
  }
  for (const el of candidates) {
    const marked = el.closest(`[${RELOCATED_ATTR}]`);
    if (marked) continue; // already handled (and verified by maintainRelocatedBlock)
    moveToTop(el);
  }
}

// Self-healing for the moved block.
//  - Off order pages: any leftover marked block (from a layout where the
//    container persisted across SPA navigation) is hidden AND removed, so
//    it can never show on the orders list / other admin pages.
//  - On an order page: a marked block tagged with a DIFFERENT order id is a
//    stale orphan from the previous order (Shopify remounts the whole page
//    between orders) — remove it, otherwise it would sit at the top showing
//    the old order's info and block the new order's block from moving.
//  - A marked block that is not inside the correct container gets its mark
//    cleared so the move re-runs.
function maintainRelocatedBlock() {
  const marked = [...document.querySelectorAll(`[${RELOCATED_ATTR}]`)];
  const orderId = currentOrderId();

  if (!orderId) {
    marked.forEach((el) => {
      el.style.display = 'none';
      el.remove();
    });
    return;
  }

  const container = findMainContainer();
  marked.forEach((el) => {
    const taggedOrder = el.getAttribute(RELOCATED_ORDER_ATTR);
    if (taggedOrder && taggedOrder !== orderId) {
      el.style.display = 'none';
      el.remove();
      return;
    }
    el.style.display = '';
    if (container && el.parentElement !== container) {
      el.removeAttribute(RELOCATED_ATTR);
      el.removeAttribute(RELOCATED_ORDER_ATTR);
    } else if (container && container.firstElementChild !== el) {
      // Cards that mount AFTER the move (e.g. "Order metafields") land above
      // the block. Re-assert the top position; same parent, so React's own
      // bookkeeping is unaffected.
      container.insertBefore(el, container.firstElementChild);
    }
  });
  attemptAutoMove();
}

// ------------------------------------------------------------
// "Deleted items" card: HIDDEN (popup checkbox, on by default).
// Found by heading text, since it has no stable class.
// Unchecking the box restores it immediately (marker attribute).
// ------------------------------------------------------------

// Headings on the order page are <s-internal-heading> in the current admin; keep the
// generic fallbacks for older markup.
const DELETED_HEADING_SELECTOR = 'h1, h2, h3, h4, h5, h6, s-internal-heading, [class*="Heading"]';

function findDeletedItemsCard() {
  if (!isOrderDetailPage()) return null;
  const container = findMainContainer();
  if (!container) return null;
  const appBlock = document.querySelector(MOVE_BLOCK_SELECTOR);
  const headings = container.querySelectorAll(DELETED_HEADING_SELECTOR);
  for (const h of headings) {
    if (!DELETED_HEADING_RE.test((h.textContent || '').trim())) continue;
    if (appBlock && appBlock.contains(h)) continue; // heading inside the app block itself
    // The card is the heading's Polaris-Box ancestor (one Box per card in the main
    // column's BlockStack). Fallback: climb to the container's direct child. If neither
    // resolves, skip rather than hide something random. Never hide a card that
    // contains the app block or the whole column.
    let card = h.closest('.Polaris-Box');
    if (!card) {
      card = h;
      while (card.parentElement && card.parentElement !== container) card = card.parentElement;
      if (card.parentElement !== container) card = null;
    }
    if (!card || card === container) continue;
    if (appBlock && card.contains(appBlock)) continue;
    return card;
  }
  return null;
}

function attemptDeletedItems() {
  if (!settings.hideDeletedItems || !isOrderDetailPage()) {
    restoreDeletedItems();
    return;
  }
  const card = findDeletedItemsCard();
  if (!card) return;
  card.setAttribute(DELETED_ATTR, 'true');
  if (card.style.display !== 'none') card.style.display = 'none';
}

// Un-hide a previously hidden card (setting turned off mid-session / left the page).
function restoreDeletedItems() {
  document.querySelectorAll(`[${DELETED_ATTR}]`).forEach((el) => {
    if (el.style.display === 'none') el.style.display = '';
    el.removeAttribute(DELETED_ATTR);
  });
}

// ------------------------------------------------------------
// Hiding engine.
//  1. Light-DOM elements (LineItemGroup) - a normal <style> tag
//     covers these, including elements that render later.
//  2. Shadow-DOM elements (the Edit button) - document CSS can't
//     reach inside shadow roots, so we inject the same <style>
//     into every OPEN shadow root and re-walk on navigation /
//     mutations / menu opens.
// Both are applied ONLY on order detail pages and fully removed
// (style tags deleted, per-element hides restored) everywhere else.
// ------------------------------------------------------------
function buildHideCss() {
  const parts = [];
  if (settings.hideEditBtn) {
    parts.push(`${EDIT_BTN_SELECTOR} { display: none !important; }`);
  }
  if (settings.hideLineItems) {
    parts.push(`${LINE_ITEMS_SELECTOR} { display: none !important; }`);
  }
  return parts.join('\n');
}

function ensureHideStyle(root, css) {
  const host = root === document ? document.head || document.documentElement : root;
  let style = host.querySelector(`style[${HIDE_STYLE_ATTR}]`);
  if (!css) {
    if (style) style.remove();
    return;
  }
  if (!style) {
    style = document.createElement('style');
    style.setAttribute(HIDE_STYLE_ATTR, 'true');
    host.appendChild(style);
  }
  if (style.textContent !== css) style.textContent = css;
}

// Visit every open shadow root in the document (recursively).
function forEachShadowRoot(cb, root = document) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let node = walker.currentNode;
  while (node) {
    if (node.shadowRoot) {
      cb(node.shadowRoot);
      forEachShadowRoot(cb, node.shadowRoot);
    }
    node = walker.nextNode();
  }
}

/**
 * Spring '26 Edit buttons carry no href, so they're hidden per-element by EXACT text
 * match instead of CSS. Runs against one root (document or a shadow root).
 */
function hideEditButtonsByText(root) {
  root.querySelectorAll(EDIT_BTN_TEXT_CANDIDATES).forEach((el) => {
    if ((el.textContent || '').trim() !== 'Edit') return;
    if (el.style.display !== 'none') {
      el.setAttribute(EDIT_HIDE_ATTR, 'true');
      el.style.display = 'none';
    }
  });
}

function restoreEditButtons(root) {
  root.querySelectorAll(`[${EDIT_HIDE_ATTR}]`).forEach((el) => {
    el.style.display = '';
    el.removeAttribute(EDIT_HIDE_ATTR);
  });
}

function applyHides() {
  if (!isOrderDetailPage()) {
    removeHides();
    return;
  }
  const css = buildHideCss();
  const perRoot = settings.hideEditBtn ? hideEditButtonsByText : restoreEditButtons;
  ensureHideStyle(document, css);
  perRoot(document);
  forEachShadowRoot((shadowRoot) => {
    ensureHideStyle(shadowRoot, css);
    perRoot(shadowRoot);
  });
}

function removeHides() {
  ensureHideStyle(document, '');
  restoreEditButtons(document);
  forEachShadowRoot((shadowRoot) => {
    ensureHideStyle(shadowRoot, '');
    restoreEditButtons(shadowRoot);
  });
}

// ------------------------------------------------------------
// SPA navigation detection.
// Shopify admin uses client-side routing, so we patch
// pushState/replaceState + listen for popstate, and also run
// a MutationObserver + a retry ticker as fallbacks.
// ------------------------------------------------------------
function notifyLocationChange() {
  window.dispatchEvent(new Event('spa-locationchange'));
}

(function patchHistory() {
  const origPush = history.pushState;
  const origReplace = history.replaceState;
  history.pushState = function (...args) {
    origPush.apply(history, args);
    notifyLocationChange();
  };
  history.replaceState = function (...args) {
    origReplace.apply(history, args);
    notifyLocationChange();
  };
  window.addEventListener('popstate', notifyLocationChange);
})();

function runAutoActions() {
  if (isOrderDetailPage()) {
    maintainRelocatedBlock();
    attemptDeletedItems();
    if (settings.hideEditBtn || settings.hideLineItems) applyHides();
    else removeHides();
  } else {
    // Not an order page: undo everything so nothing leaks onto other pages.
    maintainRelocatedBlock();
    restoreDeletedItems();
    removeHides();
  }
}

// --- Scheduling ---------------------------------------------
// v4 used a trailing 500 ms debounce on DOM mutations. The order page keeps
// mutating in bursts shorter than that for several seconds after load
// (skeletons, polling, app iframes), so the debounce kept resetting and the
// block was moved late (8 s+ measured) or, on a busy session, never —
// "the plugin didn't open on this order". Now:
//  1. mutations schedule ONE run 250 ms out and never push it back
//     (throttle, not debounce);
//  2. a ticker retries every 500 ms for the first 20 s after every
//     navigation/load, then every 2 s, so a late-rendering block is
//     always picked up.
let scheduled = null;
function scheduleRun() {
  if (scheduled) return;
  scheduled = setTimeout(() => {
    scheduled = null;
    runAutoActions();
  }, 250);
}

let tickerTimer = null;
let tickerStartedAt = 0;
function restartTicker() {
  tickerStartedAt = Date.now();
  if (tickerTimer) return;
  const tick = () => {
    runAutoActions();
    const fast = Date.now() - tickerStartedAt < 20000;
    tickerTimer = setTimeout(tick, fast ? 500 : 2000);
  };
  tickerTimer = setTimeout(tick, 500);
}

let watching = false;
function startWatching() {
  if (watching) {
    runAutoActions();
    return;
  }
  watching = true;

  // Try immediately (in case the page is already rendered)
  runAutoActions();
  restartTicker();

  // Re-try on SPA route change (allow time for React to render), and
  // restart the fast ticker for the new page.
  window.addEventListener('spa-locationchange', () => {
    runAutoActions(); // immediate: clears hides/leftovers when LEAVING an order page
    setTimeout(runAutoActions, 700);
    setTimeout(runAutoActions, 1500);
    restartTicker();
  });

  // Fallback: watch DOM mutations in case content loads async
  // without a URL change. Throttled to avoid performance issues.
  const observer = new MutationObserver(scheduleRun);
  observer.observe(document.body, { childList: true, subtree: true });

  // Menus (More actions dropdown) create NEW shadow roots when they
  // open, and a document observer can't see inside them. A click
  // anywhere is the cheapest reliable signal that a menu may have
  // just rendered - re-apply hides shortly after (order pages only).
  document.addEventListener('click', () => {
    if (!isOrderDetailPage()) return;
    if (!settings.hideEditBtn && !settings.hideLineItems) return;
    setTimeout(applyHides, 100);
    setTimeout(applyHides, 400);
  }, true);
}
