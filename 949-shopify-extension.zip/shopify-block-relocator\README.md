# 949 Shopify (v4)

Chrome extension for the 949 Racing team. On Shopify admin **order pages** it:

1. **Moves the app block to the top** (the 949 bundle editor / "Blocks"
   section) — always on, not configurable
2. **Hides the order "Edit" button** (header + "More actions" menu copies)
3. **Hides the line items list** inside the fulfillment card
4. **Hides the "Removed"/"Deleted items" card**

Everything is **on by default**. The popup is three checkboxes and a Save
button — no selectors, nothing to configure.

## For the team (non-developers)

1. `chrome://extensions/` → enable **Developer Mode** → **Load unpacked** →
   select this folder
2. Open any Shopify admin order page — the tweaks apply automatically
3. To turn something off: click the extension icon, uncheck it, hit **Save**,
   and refresh the page

That's it.

## For developers: where the selectors live

All selectors are **hardcoded at the top of [inject.js](inject.js)**. The team
never touches them — if Shopify changes its class names, update the constants
and re-distribute:

| Constant | Current value | What it targets |
|---|---|---|
| `MOVE_BLOCK_SELECTOR` | `[class*="OrderDetailsAppBlockExtensionsWrapper"]` | The app-blocks wrapper (`_OrderDetailsAppBlockExtensionsWrapper_6wznd_116` — the hash suffix changes between Shopify deploys, so we substring-match the stable part) |
| `LINE_ITEMS_SELECTOR` | `[class*="LineItemGroup"]` | Line-items list in the fulfillment card (`_LineItemGroup_z9606_1`) |
| `EDIT_BTN_SELECTOR` | `s-internal-button[href*="/orders/"][href$="/edit"], a[href*="/orders/"][href$="/edit"]` | The order Edit button in the OLD admin markup (pre-Spring '26) — see note below |
| `EDIT_BTN_TEXT_CANDIDATES` | `s-internal-button, button[role="menuitem"]` | Spring '26 admin removed the href from the Edit button (`<s-internal-button id="Edit">` + href-less menu copies), so these candidates are hidden per-element by **exact text "Edit"** in JS. Exact match keeps the app block's "View/Edit" and icon-only pencil buttons safe. |
| `DELETED_HEADING_RE` | `/^(deleted\|removed)(\s+items?)?(\s*\(\d+\))?$/i` | The "Removed"/"Deleted items" card, found by its **heading text** (`<s-internal-heading>`, no stable class). Matches "Deleted items", "Removed items", "Removed (15)". The card (its `.Polaris-Box` ancestor) is hidden while the popup checkbox is on. |

### Why the Edit button is special (Shadow DOM + Spring '26)

Historically the Edit button was an `<s-internal-button href=".../orders/<id>/edit">`
rendered **inside the Shadow DOM** of `<s-internal-page>`, with copies inside
`<s-menu>` overflow menus. `document.querySelector` and document-level CSS
cannot reach inside shadow roots. The extension therefore injects a
`display:none` stylesheet into **every open shadow root** it can find, and
re-injects on SPA navigation, DOM mutations, and clicks (menus create new
shadow roots when they open).

The **Spring '26 admin removed the href** from these buttons (now
`<s-internal-button id="Edit">` plus href-less menu copies), so the CSS rule
alone no longer catches them. The same shadow-root walk now ALSO hides, per
element, any `s-internal-button` / `button[role="menuitem"]` whose text is
**exactly** "Edit" (marked with `data-block-relocator-edit-hidden` so
unchecking the popup box restores them). Exact-match keeps the app block's
"View/Edit" buttons and icon-only pencil buttons (empty text) untouched. The
old href CSS rule is kept for stores still on the previous admin markup.

### Other implementation notes

- **Moving uses `insertBefore`, never `cloneNode`** — cloning drops
  JS-created Shadow DOM content and the block renders empty.
- **Shopify admin is a SPA** — `pushState`/`replaceState` are patched and a
  debounced `MutationObserver` re-applies everything after client-side
  navigation or async renders.
- Light-DOM hides (line items) are pure CSS, so they apply instantly even to
  elements that render after us.
- Settings live in `chrome.storage.sync` as three booleans
  (`hideEditBtn`, `hideLineItems`, `hideDeletedItems`), all defaulting to
  `true`. The block move has no setting — it always runs.
- The Deleted-items card is found by heading **text**, not class, because
  Shopify gives it no stable class. The whole card (the heading's
  `.Polaris-Box` ancestor) is hidden inline and marked with
  `data-deleted-items-ext`; unchecking the box restores it immediately.
  If the heading isn't found, nothing is touched.
