# 949 Shopify (v4.1)

Chrome extension for the 949 Racing team. On Shopify admin **order pages** it:

1. **Moves the app block to the top** (the 949 bundle editor / "Blocks"
   section) — always on, not configurable
2. **Hides the order "Edit" button** (header + "More actions" menu copies)
3. **Hides the line items list** inside the fulfillment card
4. **Hides the "Removed"/"Deleted items" card**

Everything is **on by default**. The popup is three checkboxes and a Save
button — no selectors, nothing to configure.

## For the team (non-developers)

1. `chrome://extensions/` → enable **Developer Mode** → **Load unpacked** →
   select this folder
2. Open any Shopify admin order page — the tweaks apply automatically
3. To turn something off: click the extension icon, uncheck it, hit **Save**,
   and refresh the page

That's it.

## For developers: where the selectors live

All selectors are **hardcoded at the top of [inject.js](inject.js)**. The team
never touches them — if Shopify changes its class names, update the constants
and re-distribute:

| Constant | Current value | What it targets |
|---|---|---|
| `MOVE_BLOCK_SELECTOR` | `[class*="OrderDetailsAppBlockExtensionsWrapper"]` | The app-blocks wrapper (`_OrderDetailsAppBlockExtensionsWrapper_6wznd_116` — the hash suffix changes between Shopify deploys, so we substring-match the stable part) |
| `LINE_ITEMS_SELECTOR` | `[class*="LineItemGroup"], div:has(> [class*="LineItemContainer"]), [class*="LineItemContainer"]` | Line-items list in the fulfillment card. Old markup: `_LineItemGroup_z9606_1`. Current (Nov '26): rows are `_LineItemContainer_shcz3_xx` inside a `_Grid_agsy0_7` wrapper — the `:has` rule hides the wrapper (rows + dividers), the last rule is a per-row fallback. |
| `EDIT_BTN_SELECTOR` | `s-internal-button[href*="/orders/"][href$="/edit"], a[href*="/orders/"][href$="/edit"]` | The order Edit button in the OLD admin markup (pre-Spring '26) — see note below |
| `EDIT_BTN_TEXT_CANDIDATES` | `s-internal-button, button[role="menuitem"]` | Spring '26 admin removed the href from the Edit button (`<s-internal-button id="Edit">` + href-less menu copies), so these candidates are hidden per-element by **exact text "Edit"** in JS. Exact match keeps the app block's "View/Edit" and icon-only pencil buttons safe. |
| `DELETED_HEADING_RE` | `/^(deleted\|removed)(\s+items?)?(\s*\(\d+\))?$/i` | The "Removed"/"Deleted items" card, found by its **heading text** (`<s-internal-heading>`, no stable class). Matches "Deleted items", "Removed items", "Removed (15)". The card (its `.Polaris-Box` ancestor) is hidden while the popup checkbox is on. |

### Why the Edit button is special (Shadow DOM + Spring '26)

Historically the Edit button was an `<s-internal-button href=".../orders/<id>/edit">`
rendered **inside the Shadow DOM** of `<s-internal-page>`, with copies inside
`<s-menu>` overflow menus. `document.querySelector` and document-level CSS
cannot reach inside shadow roots. The extension therefore injects a
`display:none` stylesheet into **every open shadow root** it can find, and
re-injects on SPA navigation, DOM mutations, and clicks (menus create new
shadow roots when they open).

The **Spring '26 admin removed the href** from these buttons (now
`<s-internal-button id="Edit">` plus href-less menu copies), so the CSS rule
alone no longer catches them. The same shadow-root walk now ALSO hides, per
element, any `s-internal-button` / `button[role="menuitem"]` whose text is
**exactly** "Edit" (marked with `data-block-relocator-edit-hidden` so
unchecking the popup box restores them). Exact-match keeps the app block's
"View/Edit" buttons and icon-only pencil buttons (empty text) untouched. The
old href CSS rule is kept for stores still on the previous admin markup.

### Where the block gets moved to (three admin layouts)

Shopify is mid-rollout on a new order-page layout, so `findMainContainer()`
in [inject.js](inject.js) tries three strategies in order:

1. **Old layout:** `[class*="OrderDetailsMainColumn"]` — insert at its top.
2. **New layout (Spring '26):** columns are built inside `<s-internal-page>`'s
   Shadow DOM via slots. Its light-DOM child **without** a `slot` attribute is
   the main cards column — insert there. (Inserting any higher, e.g. into
   `<main>`, makes the block render as its own grid column BESIDE the cards
   instead of above them.)
3. **Interim layout:** widest non-wrapper child of `[class*="OrderDetailsLayout"]`.

If none match, the move is skipped and retried on the next DOM mutation —
never dumped somewhere wrong.

### Other implementation notes

- **Moving uses `insertBefore`, never `cloneNode`** — cloning drops
  JS-created Shadow DOM content and the block renders empty.
- **Everything is scoped to order DETAIL pages** (`/orders/<id>`). On the
  orders list, every other admin page, and `/orders/<id>/edit`, all injected
  hide styles are removed, hidden Edit buttons are restored, and any leftover
  relocated block is removed from the DOM. (v4.0 applied the Edit-button hide
  on every admin page.)
- **Shopify admin is a SPA** — `pushState`/`replaceState` are patched and a
  throttled `MutationObserver` plus a retry ticker (every 500 ms for 20 s
  after each navigation, then every 2 s) re-apply everything after
  client-side navigation or async renders. v4.0 used a trailing 500 ms
  *debounce*; the order page mutates in sub-500 ms bursts for seconds after
  load, so the move landed 4–8 s late or, on a busy session, never ("the
  plugin didn't open on this order").
- **The moved block is tagged with its order id** (`data-relocated-order`).
  Shopify remounts the whole page between orders, so a block tagged with a
  different id is an orphan from the previous order and is removed instead of
  being re-shown at the top of the new order. The block is also re-asserted
  as the FIRST child on every pass, because cards that mount after the move
  (e.g. "Order metafields") would otherwise land above it.
- Light-DOM hides (line items) are pure CSS, so they apply instantly even to
  elements that render after us.
- Settings live in `chrome.storage.sync` as three booleans
  (`hideEditBtn`, `hideLineItems`, `hideDeletedItems`), all defaulting to
  `true`. The block move has no setting — it always runs.
- The Deleted-items card is found by heading **text**, not class, because
  Shopify gives it no stable class. The whole card (the heading's
  `.Polaris-Box` ancestor) is hidden inline and marked with
  `data-deleted-items-ext`; unchecking the box restores it immediately.
  If the heading isn't found, nothing is touched.
