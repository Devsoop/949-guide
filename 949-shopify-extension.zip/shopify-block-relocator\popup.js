const hideEditBtn = document.getElementById('hideEditBtn');
const hideLineItems = document.getElementById('hideLineItems');
const hideDeletedItems = document.getElementById('hideDeletedItems');
const saveBtn = document.getElementById('saveBtn');
const messageDiv = document.getElementById('message');

// Load saved settings (everything defaults to ON)
const DEFAULTS = { hideEditBtn: true, hideLineItems: true, hideDeletedItems: true };

chrome.storage.sync.get(DEFAULTS, (data) => {
  hideEditBtn.checked = data.hideEditBtn;
  hideLineItems.checked = data.hideLineItems;
  hideDeletedItems.checked = data.hideDeletedItems;
});

function getActiveTab(cb) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) cb(tabs[0]);
  });
}

function sendToTab(message, cb) {
  getActiveTab((tab) => {
    if (!tab.url || !tab.url.includes('admin.shopify.com')) {
      // Not on the admin - settings are saved, they'll apply there.
      cb && cb(null);
      return;
    }

    chrome.tabs.sendMessage(tab.id, message, (response) => {
      if (chrome.runtime.lastError) {
        // Content script isn't attached yet (common right after installing/
        // reloading the extension, or on a tab that was already open).
        // Auto-inject it now, then retry once.
        chrome.scripting.executeScript(
          { target: { tabId: tab.id }, files: ['inject.js'] },
          () => {
            if (chrome.runtime.lastError) {
              cb && cb(null);
              return;
            }
            setTimeout(() => {
              chrome.tabs.sendMessage(tab.id, message, (retryResponse) => {
                if (chrome.runtime.lastError) {
                  cb && cb(null);
                  return;
                }
                cb && cb(retryResponse);
              });
            }, 150);
          }
        );
        return;
      }
      cb && cb(response);
    });
  });
}

saveBtn.addEventListener('click', () => {
  const settings = {
    hideEditBtn: hideEditBtn.checked,
    hideLineItems: hideLineItems.checked,
    hideDeletedItems: hideDeletedItems.checked
  };

  chrome.storage.sync.set(settings, () => {
    sendToTab({ action: 'applySettings', settings }, () => {
      showMessage('✓ Saved!', 'success');
    });
  });
});

function showMessage(text, type) {
  messageDiv.textContent = text;
  messageDiv.className = 'message ' + type;
  setTimeout(() => { messageDiv.className = 'message'; }, 4000);
}
